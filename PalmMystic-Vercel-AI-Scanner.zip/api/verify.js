import Stripe from 'stripe';
export default async function handler(req,res){
 res.setHeader('Cache-Control','no-store');
 if(req.method!=='GET')return res.status(405).json({error:'Method not allowed'});
 const key=process.env.STRIPE_SECRET_KEY;
 if(!key)return res.status(503).json({paid:false});
 const sessionId=req.query.session_id;
 if(typeof sessionId!=='string'||!/^cs_(test_|live_)[A-Za-z0-9]+$/.test(sessionId))return res.status(400).json({paid:false});
 try{
  const stripe=new Stripe(key);
  const session=await stripe.checkout.sessions.retrieve(sessionId);
  return res.status(200).json({paid:session.payment_status==='paid'&&session.metadata?.product==='palmystic-reading-v1'});
 }catch(e){return res.status(400).json({paid:false});}
}
