import Stripe from 'stripe';
export default async function handler(req,res){
 if(req.method!=='POST')return res.status(405).json({error:'Method not allowed'});
 const key=process.env.STRIPE_SECRET_KEY;
 if(!key)return res.status(503).json({error:'Payments are not configured yet.'});
 try{
  const stripe=new Stripe(key);
  const origin=(process.env.PUBLIC_SITE_URL||`https://${req.headers.host}`).replace(/\/$/,'');
  if(!/^https:\/\//.test(origin))throw new Error('Set PUBLIC_SITE_URL to your HTTPS Vercel URL.');
  const session=await stripe.checkout.sessions.create({mode:'payment',line_items:[{price_data:{currency:'usd',unit_amount:100,product_data:{name:'PalmMystic Personalized Entertainment Reading'}} ,quantity:1}],success_url:`${origin}/?session_id={CHECKOUT_SESSION_ID}`,cancel_url:`${origin}/?canceled=1`,metadata:{product:'palmystic-reading-v1'}});
  return res.status(200).json({url:session.url});
 }catch(e){return res.status(500).json({error:'Checkout unavailable. Check Stripe settings.'});}
}
