export default async function handler(req,res){
 if(req.method!=='POST')return res.status(405).json({error:'Method not allowed'});
 const key=process.env.OPENAI_API_KEY;
 if(!key)return res.status(503).json({error:'Palm scanner is not configured. Add OPENAI_API_KEY in Vercel Preview.'});
 const image=req.body?.image;
 if(typeof image!=='string'||!/^data:image\/(jpeg|png|webp);base64,/.test(image)||image.length>6_000_000)return res.status(400).json({error:'Upload a JPG, PNG or WebP palm photo under 4 MB.'});
 try{
  const controller=new AbortController();const timeout=setTimeout(()=>controller.abort(),25000);
  let response;
  try{response=await fetch('https://api.openai.com/v1/chat/completions',{method:'POST',signal:controller.signal,headers:{Authorization:`Bearer ${key}`,'Content-Type':'application/json'},body:JSON.stringify({model:'gpt-4.1-mini',response_format:{type:'json_object'},max_tokens:650,messages:[{role:'system',content:'You describe visible palm creases cautiously and provide traditional palmistry entertainment interpretations. Never assert predictions, diagnoses, longevity, or certainty. If a line is unclear, explicitly say so. Return only a JSON object with string fields heart, head, life, fate. Each field 1-2 sentences.'},{role:'user',content:[{type:'text',text:'Describe visible palm creases and give a cautious, playful traditional palmistry interpretation for the heart, head, life, and fate lines. If this is not a clear palm photo, explain the uncertainty in each field.'},{type:'image_url',image_url:{url:image,detail:'low'}}]}]})});}finally{clearTimeout(timeout)}
  if(!response.ok)return res.status(502).json({error:'Palm analysis service is unavailable. Check the API key and billing.'});
  const payload=await response.json();const parsed=JSON.parse(payload.choices?.[0]?.message?.content||'{}');
  const result={};for(const k of ['heart','head','life','fate'])result[k]=String(parsed[k]||'Not clearly visible in this image.').slice(0,500);
  res.setHeader('Cache-Control','no-store');return res.status(200).json(result);
 }catch{return res.status(502).json({error:'Could not analyze this image. Try a clear, well-lit palm photo.'});}
}
