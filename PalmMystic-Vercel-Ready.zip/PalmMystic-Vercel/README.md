# PalmMystic — Vercel Deployment

## Deploy from GitHub
1. Create a GitHub repository named `palmystic`.
2. Upload the **contents of this folder** (index.html, api/, package.json, vercel.json, README.md). Do not upload the ZIP as a single file.
3. In Vercel select **Add New → Project → Import Git Repository**, choose `palmystic`.
4. Set Framework Preset to **Other**, Root Directory to repository root, and leave Build Command blank. Deploy.
5. Vercel will issue a `.vercel.app` URL. The site can be previewed immediately, but payments will not work until configured.

## Enable Stripe checkout
1. Create or use a Stripe account and find your **test-mode secret key** in Stripe Dashboard → Developers → API keys.
2. In Vercel → Project → Settings → Environment Variables add `STRIPE_SECRET_KEY` (secret key) and `PUBLIC_SITE_URL` (full HTTPS deployment URL, no trailing slash).
3. Redeploy. Use Stripe test mode and a Stripe-provided test card to verify checkout and download.
4. When ready for real transactions, switch to Stripe live secret key, verify the business and payment settings, redeploy and make a small real transaction to test.
5. Never paste secret keys into chat, HTML, GitHub, or client-side code.

## What works and what doesn't
- Works: purple/lavender/silver mobile layout, local palm photo preview, general palmistry interpretations, Stripe Checkout session creation for $1, server-side payment status verification, and a downloadable TXT report after verified payment.
- Does NOT yet work: actual AI line detection or individualized interpretations from the image. The uploaded photo stays in the browser and is not sent to a vision model.
- The download is generated in the customer's browser after successful payment verification. It is not an emailed or permanently stored report; if the customer loses the page, there is no customer portal or automatic resend.
- For production-grade paid fulfillment, implement durable order records, Stripe webhooks, secure signed download links, refunds/customer support, and privacy/terms pages before broad launch.
- Stripe transaction fees may take a substantial portion of a $1 sale; review Stripe pricing.

Colors: purple #54258B, lavender #DCCAF4, silver #C0C0C0.
